#ifndef GHOST_BITMAP_H
#define GHOST_BITMAP_H
extern const unsigned short ghost[225];
#define GHOST_WIDTH 15
#define GHOST_HEIGHT 15
#endif