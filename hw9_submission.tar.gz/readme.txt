YEA WON YOON
903076043

HELLO! 
WELCOME TO *GHOST* GAME

The boy wants to go home but there are too many ghosts on the way to his house.
Please lead the boy safely to his home.

To start, press ENTER (START).
To go back to HOME, press BACKSPACE (SELECT).

To move left, press LEFT ARROW (LEFT). 
To move right, press RIGHT ARROW (RIGHT). 
To move up, press UP ARROW (UP). 
To move down, press DOWN ARROW (DOWN). 

To restart the game, press BACKSPACE (SELECT).


