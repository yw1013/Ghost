#ifndef HOUSE_BITMAP_H
#define HOUSE_BITMAP_H
extern const unsigned short house[225];
#define HOUSE_WIDTH 15
#define HOUSE_HEIGHT 15
#endif