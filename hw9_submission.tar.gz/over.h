#ifndef OVER_BITMAP_H
#define OVER_BITMAP_H
extern const unsigned short over[38400];
#define OVER_WIDTH 240
#define OVER_HEIGHT 160
#endif