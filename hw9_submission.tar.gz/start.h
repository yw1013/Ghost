#ifndef START_BITMAP_H
#define START_BITMAP_H
extern const unsigned short start[38400];
#define START_WIDTH 240
#define START_HEIGHT 160
#endif