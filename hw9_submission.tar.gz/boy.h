#ifndef BOY_BITMAP_H
#define BOY_BITMAP_H
extern const unsigned short boy[225];
#define BOY_WIDTH 15
#define BOY_HEIGHT 15
#endif